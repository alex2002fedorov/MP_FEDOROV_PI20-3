package com.example.a3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private TextView text1;
    private EditText edittext;
    int a = 0;
    int b = 100;
    int number1 = a + (int) (Math.random() * b);
    String s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text1 = (TextView) findViewById(R.id.text1);
        edittext = (EditText) findViewById(R.id.edittext);
        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(clickListener1);
    }
    View.OnClickListener clickListener1 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String a = edittext.getText().toString();
            int q = Integer.parseInt(a);

            if (q>number1){
                s="Загаданное число меньше " + q + number1;
            }
            if (q<number1){
                s="Загаданное число больше " + q + number1;
            }
            if (q==number1){
                s="Ура, победа!";
            }
            edittext.getText().clear();
            text1.setText(s.toCharArray(),0, s.length());

        }
    };
}