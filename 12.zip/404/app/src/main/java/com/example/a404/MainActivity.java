package com.example.a404;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button alg,geo,exit,tab;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        alg = (Button) findViewById(R.id.alg);
        alg.setOnClickListener(button1);
        geo = (Button) findViewById(R.id.geo);
        geo.setOnClickListener(button2);
        tab = (Button) findViewById(R.id.tab);
        tab.setOnClickListener(button4);
        exit = (Button) findViewById(R.id.exit);
        exit.setOnClickListener(button3);
    };
    View.OnClickListener button1 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent= new Intent(".alg");
            startActivity(intent);
        }
    };

    View.OnClickListener button2 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent= new Intent(".geo");
            startActivity(intent);
        }
    };
    View.OnClickListener button4 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent= new Intent(".tab");
            startActivity(intent);
        }
    };
    View.OnClickListener button3 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            System.exit(1);
        }

    };


}