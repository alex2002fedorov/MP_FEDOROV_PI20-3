package com.example.a404;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class geo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_geo);
    }
}